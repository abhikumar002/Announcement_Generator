Fisrtly, we are thankful you for chosing our software.......
So, Lets Start....

#-------------------------------------------------------------------------------
Regarding,installation :-

Step1 :- Firstly, Unzip the compressed file
       :-  Go to announcement generator software file

#-------------------------------------------------------------------------------

Step2 :- Update the annoucement_hindi.xlsx file with information

#-------------------------------------------------------------------------------

Step4 :- Now, Start the .exe file.

#-------------------------------------------------------------------------------

New files will be form in that folder announcement_[train no].mp3 

Open that mp3 -> listen annoucement and enjoy our software...





